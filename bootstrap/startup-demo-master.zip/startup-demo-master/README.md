Startup Framework: Demo Version
============

<img src="https://raw.github.com/designmodo/startup-demo/master/index.jpg" title="StartUp Framework intro image" />

We have created this demo version in order to show you the structure of Startup Framework. It has some of the components from the full version, 2 great samples and documentation. You can also find 2 images of a Macbook and an iPad, which you can use in your project. We hope you will like your first introduction to Startup Framework.

> [Take a look at the demo](http://designmodo.github.io/startup-demo)

> [Watch the presentation](http://designmodo.com/startup)
